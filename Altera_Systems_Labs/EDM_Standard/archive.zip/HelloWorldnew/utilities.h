/*
 * utilities.h
 *
 *  Created on: 25 Feb 2014
 *      Author: Queron
 */

#ifndef UTILITIES_H_
#define UTILITIES_H_


#endif /* UTILITIES_H_ */
