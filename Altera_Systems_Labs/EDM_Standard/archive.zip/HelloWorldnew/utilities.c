/*
 * utilities.c
 *
 *  Created on: 25 Feb 2014
 *      Author: Queron
 */

